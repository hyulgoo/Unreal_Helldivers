
#include "HDCharacterBase.h"
#include "Components/CapsuleComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "CharacterTypes/HDCharacterStateTypes.h"
#include "Component/HDAbilitySystemComponent.h"
#include "Animation/AnimMontage.h"
#include "Collision/HDCollision.h"
#include "Define/HDDefine.h"
#include "GameData/HDCharacterStat.h"

AHDCharacterBase::AHDCharacterBase()
    : DeadMontage(nullptr)
    , DeadEventDelayTime(10.f)
    , AbilitySystemComponent(nullptr)
    , Abilities{}
    , ArmorType(EHDArmorType::Medium)
    , ArmorTypeStatusDataTable(nullptr)
    , InitAttributeStatEffect(nullptr)
{
	// Pawn
	bUseControllerRotationPitch = false;
	bUseControllerRotationYaw	= false;
	bUseControllerRotationRoll	= false;

	// Capsule
	GetCapsuleComponent()->InitCapsuleSize(42.f, 96.f);
	GetCapsuleComponent()->SetCollisionProfileName(HDCOLLISION_PROFILE_CAPSULE);

	// Movement
	UCharacterMovementComponent* CharacterMovementComponent = GetCharacterMovement();
	CharacterMovementComponent->bOrientRotationToMovement	= true;
	CharacterMovementComponent->RotationRate				= FRotator(0.f, 45.f, 0.f);
	CharacterMovementComponent->AirControl					= 0.35f;
	CharacterMovementComponent->MaxWalkSpeed				= 180.f;
	CharacterMovementComponent->MinAnalogWalkSpeed			= 20.f;
	CharacterMovementComponent->BrakingDecelerationWalking	= 2000.f;

	// Mesh
	USkeletalMeshComponent* SkeletalMeshComponent = GetMesh();
	SkeletalMeshComponent->SetRelativeLocationAndRotation(FVector(0.f, 0.f, -100.f), FRotator(0.f, -90.f, 0.f));
	SkeletalMeshComponent->SetAnimationMode(EAnimationMode::AnimationBlueprint);
	SkeletalMeshComponent->SetCollisionProfileName(HDCOLLISION_PROFILE_PLAYER);

	LoadDefaultMontage();
}

UAbilitySystemComponent* AHDCharacterBase::GetAbilitySystemComponent() const
{
    return Cast<UAbilitySystemComponent>(AbilitySystemComponent);
}

void AHDCharacterBase::SetAbilitySystemComponent(AActor* OwnerActor, UAbilitySystemComponent* ASC, const EHDCharacterType CharacterType)
{
    AbilitySystemComponent = Cast<UHDAbilitySystemComponent>(ASC);
    NULL_CHECK(AbilitySystemComponent);

    for (const TSubclassOf<UGameplayAbility>& Ability : Abilities)
    {
        AbilitySystemComponent->GiveAbility(Ability);
    }

    AbilitySystemComponent->InitAbilityActorInfo(OwnerActor, this);
    AbilitySystemComponent->InitAttributeSet();
    AbilitySystemComponent->SetAttributeSetStat(GetAttributeStatDataByArmorType(ArmorType), InitAttributeStatEffect);
}

void AHDCharacterBase::SetDead()
{
    GetMesh()->SetSimulatePhysics(true);
	GetCharacterMovement()->DisableMovement();
    PlayAnimMontage(DeadMontage, 1.f);
	GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::NoCollision);
}

void AHDCharacterBase::SetRagdoll(const bool bRagdoll, const FVector& Impulse)
{
	// Ragdoll�� ������ �ϴµ� AddImpulse�� ���� ��� Error
	CONDITION_CHECK(bRagdoll && Impulse == FVector::ZeroVector);

	USkeletalMeshComponent* CharacterMesh = GetMesh();
	CharacterMesh->SetSimulatePhysics(bRagdoll);

	if (bRagdoll)
	{
		GetCharacterMovement()->DisableMovement();
		CharacterMesh->AddImpulse(Impulse, NAME_None, true);
	}
	else
	{
		GetCharacterMovement()->SetMovementMode(MOVE_Walking);

		const FVector& BonmeLocation = CharacterMesh->GetBoneLocation("pelvis");
		const FRotator NewMeshRotation(0.f, CharacterMesh->GetComponentRotation().Yaw, 0.f);

		UCapsuleComponent* Capsule = GetCapsuleComponent();
		Capsule->SetWorldLocation(BonmeLocation);
		Capsule->SetWorldRotation(NewMeshRotation);

		CharacterMesh->SetRelativeLocationAndRotation(FVector(0.f, 0.f, -100.f), FRotator(0.f, -90.f, 0.f));
		CharacterMesh->SetAnimationMode(EAnimationMode::AnimationBlueprint);
	}
}

const float AHDCharacterBase::GetRagdollPysicsLinearVelocity() const
{
	return GetMesh()->GetPhysicsLinearVelocity().Size();
}

FHDCharacterStat* AHDCharacterBase::GetAttributeStatDataByArmorType(const EHDArmorType NewArmorType)
{
    static const UEnum* EnumPtr = StaticEnum<EHDArmorType>();
    FString ArmorTypetoString = EnumPtr->GetNameStringByValue(static_cast<int64>(NewArmorType));
    FHDCharacterStat* ArmorStatus = ArmorTypeStatusDataTable->FindRow<FHDCharacterStat>(FName(ArmorTypetoString), TEXT("ArmorStatus"));

    return ArmorStatus;
}

void AHDCharacterBase::LoadDefaultMontage()
{
	USkeletalMeshComponent* SkeletalMeshComponent = GetMesh();
	static ConstructorHelpers::FObjectFinder<USkeletalMesh> CharacterMeshRef(TEXT("/Script/Engine.SkeletalMesh'/Game/Asset/Characters/Mannequins/Meshes/SKM_Quinn.SKM_Quinn'"));
	if (CharacterMeshRef.Succeeded())
	{
		SkeletalMeshComponent->SetSkeletalMesh(CharacterMeshRef.Object);
	}

	static ConstructorHelpers::FClassFinder<UAnimInstance> AnimInstanceClassRef(TEXT("/Game/Helldivers/Animation/ABP_HDCharacter.ABP_HDCharacter_C"));
	if (AnimInstanceClassRef.Class)
	{
		SkeletalMeshComponent->SetAnimInstanceClass(AnimInstanceClassRef.Class);
	}

	static ConstructorHelpers::FObjectFinder<UAnimMontage> DeadMontageRef(TEXT("/Script/Engine.AnimMontage'/Game/Helldivers/Animation/AM_Dead.AM_Dead'"));
	if (DeadMontageRef.Succeeded())
	{
		DeadMontage = DeadMontageRef.Object;
	}
}
