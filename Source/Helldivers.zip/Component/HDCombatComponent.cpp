
#include "Component/HDCombatComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetMathLibrary.h"
#include "Engine/SkeletalMeshSocket.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "Define/HDDefine.h"
#include "Define/HDSocketNames.h"
#include "Weapon/HDWeapon.h"
#include "Character/CharacterTypes/HDCharacterStateTypes.h"

#define AIMOFFSET_PITCH_OFFSET 20.f

UHDCombatComponent::UHDCombatComponent()
    : StartingAimRotation(FRotator())
    , AimOffset_Yaw(0.f)
    , AimOffset_Pitch(0.f)
    , InterpAimOffset_Yaw(0.f)
    , bIsCharacterLookingViewport(false)
    , bUseRotateRootBone(false)
    , TurnThreshold(0.f)
    , TurningInPlace(EHDTurningInPlace::NotTurning)
    , bIsShoulder(false)
    , bIsFireButtonPressed(false)
    , CombatState(EHDCombatState::Unoccupied)
    , HitTarget(FVector())
    , DefaultFOV(50.f)
	, CurrentFOV(0.f)
    , ZoomedFOV(0.f)
	, ZoomInterpSpeed(0.f)
    , ErgonomicFactor(0.f)
	, Weapon(nullptr)
    , DefaultCurve(nullptr)
    , SpringArmArmLengthTimeline(FTimeline())
    , SpringArmTargetArmLength(0.f)
    , DefaultWeaponClass(nullptr)
    , CombatMontage{}
{
    PrimaryComponentTick.bCanEverTick = true;
}

void UHDCombatComponent::BeginPlay()
{
    Super::BeginPlay();

    CharacterMovement = GetOwner()->GetComponentByClass<UCharacterMovementComponent>();
    check(CharacterMovement);

    SpringArm = GetOwner()->GetComponentByClass<USpringArmComponent>();
    check(SpringArm);

    FOnTimelineFloat ArmLengthTimelineProgress;
    ArmLengthTimelineProgress.BindUFunction(this, FName("OnSpringArmLengthUpdate"));
    SpringArmArmLengthTimeline.AddInterpFloat(DefaultCurve, ArmLengthTimelineProgress);
    SpringArmArmLengthTimeline.SetLooping(false);
}

void UHDCombatComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
    Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

    TraceUnderCrosshairs();
    AimOffset(DeltaTime);
    SpringArmArmLengthTimeline.TickTimeline(DeltaTime);
}

const bool UHDCombatComponent::FireFinished()
{
    VALID_CHECK_WITH_RETURNTYPE(Weapon, false);

    if (bIsFireButtonPressed && Weapon->IsAutoFire())
    {
        Fire(true);
        return true;
    }
    return false;
}

void UHDCombatComponent::ReloadFinished()
{
    CombatState = EHDCombatState::Unoccupied;
}

const float UHDCombatComponent::GetAimOffset_Yaw() const
{
    return AimOffset_Yaw;
}

const float UHDCombatComponent::GetAimOffset_Pitch() const
{
    return AimOffset_Pitch;
}

const FVector& UHDCombatComponent::GetHitTarget() const
{
    return HitTarget;
}

void UHDCombatComponent::SetHitTarget(const FVector& NewHitTarget)
{
    HitTarget = NewHitTarget;
}

const float UHDCombatComponent::GetCurrentFOV() const
{
    return CurrentFOV;
}

void UHDCombatComponent::SetCurrentFOV(const float NewFOV)
{
    CurrentFOV = NewFOV;
}

const float UHDCombatComponent::GetZoomInterpSpeed() const
{
    return ZoomInterpSpeed;
}

const bool UHDCombatComponent::IsCharacterLookingViewport() const
{
    return bIsCharacterLookingViewport;
}

void UHDCombatComponent::SetSpringArmTargetLength(const float TargetArmLength)
{
    SpringArmTargetArmLength = TargetArmLength;
}

const EHDTurningInPlace UHDCombatComponent::GetTurnInPlace() const
{
    return TurningInPlace;
}

const float UHDCombatComponent::GetDefaultFOV() const
{
    return DefaultFOV;
}

const bool UHDCombatComponent::IsUseRotateBone() const
{
    return bUseRotateRootBone;
}

UAnimMontage* UHDCombatComponent::GetCombatMontage(const EHDCombatMontage MontageType)
{
    CONDITION_CHECK_WITH_RETURNTYPE(CombatMontage.Num() != static_cast<int32>(EHDCombatMontage::Count), nullptr);

    return CombatMontage[MontageType];
}

void UHDCombatComponent::TraceUnderCrosshairs()
{
    FVector2D ViewportSize;
    if (GEngine && GEngine->GameViewport)
    {
        GEngine->GameViewport->GetViewportSize(ViewportSize);
    }
    else
    {
        CONDITION_CHECK(true);
    }

    const FVector2D CrosshairLocation(ViewportSize.X / 2.f, ViewportSize.Y / 2.f);
    FVector CrosshairWorldPosition;
    FVector CrosshairWorldDirection;
    const bool bScreenToWorld = UGameplayStatics::DeprojectScreenToWorld(
        UGameplayStatics::GetPlayerController(this, 0),
        CrosshairLocation,
        CrosshairWorldPosition,
        CrosshairWorldDirection
    );

    if (bScreenToWorld)
    {
        FVector Start = CrosshairWorldPosition;
        const float DistanceToCharacter = (GetOwner()->GetActorLocation() - Start).Size();
        Start += CrosshairWorldDirection * (DistanceToCharacter + 100.f);

        const FVector End = Start + CrosshairWorldDirection * HITSCAN_TRACE_LENGTH;
        UWorld* World = GetWorld();
        VALID_CHECK(World);

        FHitResult TraceHitResult;
        const bool bHit = World->LineTraceSingleByChannel(TraceHitResult, Start, End, ECollisionChannel::ECC_Visibility);        

        HitTarget = bHit ? TraceHitResult.ImpactPoint : End;

        NULL_CHECK(Weapon);
        Weapon->TraceEndWithScatter(HitTarget);
    }
}

void UHDCombatComponent::AimOffset(const float DeltaTime)
{
    NULL_CHECK(CharacterMovement);

    if (IsValid(Weapon) == false)
    {
        return;
    }

	APawn* Owner = GetOwner<APawn>();
    NULL_CHECK(Owner);

    FVector Velocity = Owner->GetVelocity();
    Velocity.Z = 0.f;
    const bool bIsMoving = Velocity.Size() > 0.1f;
    const bool bIsFalling = CharacterMovement->IsFalling();
    const FRotator BaseAimRoatation = Owner->GetBaseAimRotation();
    const FRotator ControlRotation = Owner->GetControlRotation();

    if (bIsShoulder)
    {
        bIsCharacterLookingViewport = true;
        bUseRotateRootBone = false;
        Owner->bUseControllerRotationYaw = true;
        CharacterMovement->bOrientRotationToMovement = false;

        const FRotator TargetRotation(0.f, ControlRotation.Yaw, 0.f);
        const FRotator SmoothRotation = FMath::RInterpTo(Owner->GetActorRotation(), TargetRotation, DeltaTime, 20.f);
        Owner->SetActorRotation(SmoothRotation);

        if (bIsMoving == false && bIsFalling == false)
        {
            const FRotator DeltaRotation = UKismetMathLibrary::NormalizedDeltaRotator(TargetRotation, StartingAimRotation);
            AimOffset_Yaw = DeltaRotation.Yaw;

            if (TurningInPlace == EHDTurningInPlace::NotTurning)
            {
                InterpAimOffset_Yaw = AimOffset_Yaw;
            }

            TurnInPlace(DeltaTime);
        }

        if (bIsMoving || bIsFalling)
        {
            AimOffset_Yaw = 0.f;
            InterpAimOffset_Yaw = 0.f;
            StartingAimRotation = TargetRotation;
        }
    }
    else
    {
        bIsCharacterLookingViewport = true;
        bUseRotateRootBone = true;
        Owner->bUseControllerRotationYaw = false;
        CharacterMovement->bOrientRotationToMovement = false;
        const FRotator TargetRotation(0.f, BaseAimRoatation.Yaw, 0.f);
        const FRotator DeltaRotation = UKismetMathLibrary::NormalizedDeltaRotator(TargetRotation, StartingAimRotation);
        AimOffset_Yaw = DeltaRotation.Yaw;

        if (bIsMoving == false && bIsFalling == false)
        {
            if (TurningInPlace == EHDTurningInPlace::NotTurning)
            {
                InterpAimOffset_Yaw = AimOffset_Yaw;
            }

            bUseRotateRootBone = false;
            Owner->bUseControllerRotationYaw = true;
            TurnInPlace(DeltaTime);
        }

        if (bIsMoving || bIsFalling)
        {
            bIsCharacterLookingViewport = false;
            bUseRotateRootBone = false;
            AimOffset_Yaw = 0.f;
            StartingAimRotation = BaseAimRoatation;
            TurningInPlace = EHDTurningInPlace::NotTurning;
            CharacterMovement->bOrientRotationToMovement = true;
        }
    }

    AimOffset_Pitch = BaseAimRoatation.Pitch - AIMOFFSET_PITCH_OFFSET;
}

void UHDCombatComponent::TurnInPlace(const float DeltaTime)
{
    if (AimOffset_Yaw > TurnThreshold)
    {
        TurningInPlace = EHDTurningInPlace::Turn_Right;
    }
    else if (AimOffset_Yaw < -TurnThreshold)
    {
        TurningInPlace = EHDTurningInPlace::Turn_Left;
    }

    if (TurningInPlace != EHDTurningInPlace::NotTurning)
    {
        InterpAimOffset_Yaw = FMath::FInterpTo(InterpAimOffset_Yaw, 0.f, DeltaTime, 4.f);
        AimOffset_Yaw = InterpAimOffset_Yaw;
        if (FMath::Abs(AimOffset_Yaw) < 15.f)
        {
            StartingAimRotation = FRotator(0.f, GetOwner<APawn>()->GetBaseAimRotation().Yaw, 0.f);
            TurningInPlace = EHDTurningInPlace::NotTurning;
        }
    }
}

void UHDCombatComponent::OnSpringArmLengthUpdate(const float Value)
{
    const float Interpolated = FMath::Lerp(SpringArmTargetArmLength, SpringArmTargetArmLength / 2.f, Value);
    SpringArm->TargetArmLength = Interpolated;
}

const bool UHDCombatComponent::Fire(const bool IsPressed)
{
    bIsFireButtonPressed = IsPressed;

    if (bIsFireButtonPressed == false || CanFire() == false)
    {
        return false;
    }

    CombatState = EHDCombatState::Fire;
    Weapon->Fire(HitTarget, bIsShoulder);

    return true;
}

void UHDCombatComponent::EquipWeapon(AHDWeapon* NewWeapon)
{
    VALID_CHECK(NewWeapon);

    Weapon = NewWeapon;
    Weapon->SetOwner(GetOwner());
    Weapon->SetWeaponState(EWeaponState::Equip);
    ErgonomicFactor = Weapon->GetErgonomicFactor();

    USkeletalMeshComponent* SkeletalMesh = GetOwner()->GetComponentByClass<USkeletalMeshComponent>();
    NULL_CHECK(SkeletalMesh);

    const USkeletalMeshSocket* RightHandSocket = SkeletalMesh->GetSocketByName(HDSOCKETNAME_RIGRHTHAND);
    NULL_CHECK(RightHandSocket);
    RightHandSocket->AttachActor(NewWeapon, SkeletalMesh);
}

AHDWeapon* UHDCombatComponent::GetWeapon() const
{
    return Weapon;
}

void UHDCombatComponent::SetWeaponActive(const bool bActive)
{
    VALID_CHECK(Weapon);
    Weapon->SetActorTickEnabled(bActive);
    Weapon->SetActorHiddenInGame(bActive == false);
    Weapon->SetActorEnableCollision(bActive);
}

const EHDFireType UHDCombatComponent::GetWeaponFireType() const
{
    VALID_CHECK_WITH_RETURNTYPE(Weapon, EHDFireType::Count);

    return Weapon->GetFireType();
}

const float UHDCombatComponent::GetWeaponFireDelay() const
{
    VALID_CHECK_WITH_RETURNTYPE(Weapon, 0.f);

    return Weapon->GetFireDelay();
}

const int32 UHDCombatComponent::GetWeaponAmmoCount() const
{
    VALID_CHECK_WITH_RETURNTYPE(Weapon, 0);

    return Weapon->GetAmmoCount();
}

const int32 UHDCombatComponent::GetWeaponMaxAmmoCount() const
{
    VALID_CHECK_WITH_RETURNTYPE(Weapon, 0);

    return Weapon->GetMaxAmmoCount();
}

const int32 UHDCombatComponent::GetWeaponCapacityCount() const
{
    VALID_CHECK_WITH_RETURNTYPE(Weapon, 0);

    return Weapon->GetCapacityCount();
}

const int32 UHDCombatComponent::GetWeaponMaxCapacityCount() const
{
    VALID_CHECK_WITH_RETURNTYPE(Weapon, 0);

    return Weapon->GetMaxCapacityCount();
}

const float UHDCombatComponent::GetWeaponZoomedFOV() const
{
    VALID_CHECK_WITH_RETURNTYPE(Weapon, 0.f);

    return Weapon->GetCapacityCount();
}

const float UHDCombatComponent::GetWeaponZoomInterpSpeed() const
{
    VALID_CHECK_WITH_RETURNTYPE(Weapon, 0.f);

    return Weapon->GetCapacityCount();
}

const bool UHDCombatComponent::NeedReload() const
{
    return (CanReload() && Weapon->IsAmmoEmpty());
}

const bool UHDCombatComponent::CanFire() const
{
    if (IsValid(Weapon) == false || Weapon->IsAmmoEmpty())
    {
        return false;
    }

    if (Weapon->GetWeaponType() == EWeaponType::Shotgun && CombatState == EHDCombatState::Reloading)
    {
        return true;
    }

    return (CombatState == EHDCombatState::Unoccupied || CombatState == EHDCombatState::Fire);
}

void UHDCombatComponent::SpawnDefaultWeapon()
{
    NULL_CHECK(DefaultWeaponClass);

    UWorld* World = GetWorld();
    VALID_CHECK(World);

    AHDWeapon* SpawnWeapon = World->SpawnActor<AHDWeapon>(DefaultWeaponClass);
    NULL_CHECK(SpawnWeapon);
    EquipWeapon(SpawnWeapon);
}

const EHDCombatState UHDCombatComponent::GetCombatState() const
{
    return CombatState;
}

void UHDCombatComponent::SetCombatState(const EHDCombatState State)
{
    CONDITION_CHECK(CombatState == EHDCombatState::Count);

    CombatState = State;
}

const bool UHDCombatComponent::IsShoulder() const
{
    return bIsShoulder;
}

void UHDCombatComponent::SetShoulder(const bool bShoudler)
{
    bIsShoulder = bShoudler;

	if (bIsShoulder)
	{
		SpringArmArmLengthTimeline.PlayFromStart();
	}
	else
	{
		SpringArmArmLengthTimeline.ReverseFromEnd();
	}
}

const bool UHDCombatComponent::CanReload() const
{
    if (IsValid(Weapon) == false || Weapon->IsCapacityEmpty() || Weapon->IsAmmoFull())
    {
        return false;
    }

    return CombatState == EHDCombatState::Unoccupied;
}

void UHDCombatComponent::Reload()
{
    NULL_CHECK(Weapon);

    CombatState = EHDCombatState::Reloading;
    Weapon->Reload(bIsShoulder);
}

const float UHDCombatComponent::GetWeaponReloadDelay(const bool bShoulder) const
{
    VALID_CHECK_WITH_RETURNTYPE(Weapon, 0.f);

    return Weapon->GetReloadDelay(bShoulder);
}
